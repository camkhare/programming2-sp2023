console.log(localStorage.getItem("ClubHeads"));
console.log(localStorage.getItem("ClubTimes"));
console.log(localStorage.getItem("ClubDescription"));
console.log(localStorage.getItem("ClubName"));

var clubName = document.getElementById("club-name");
clubName.innerText = localStorage.getItem("clubName")